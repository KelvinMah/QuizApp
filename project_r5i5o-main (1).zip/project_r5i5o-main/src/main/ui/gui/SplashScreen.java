package ui.gui;

import javax.swing.*;
import java.awt.*;

//Code influenced by
//https://stackoverflow.com/questions/16134549/how-to-make-a-splash-screen-for-gui
//Represent the class to create a splash screen before launching the quiz app
public class SplashScreen extends JWindow {
    public static final int WIDTH = 500;
    public static final int HEIGHT = 300;

    //EFFECTS: to construct a new window that displays the image for the splash screen
    public SplashScreen() {
        JWindow window = new JWindow();
        ImageIcon img = new ImageIcon("data/quizapp.jpg");

        Image image = img.getImage();
        Image newImg = image.getScaledInstance(WIDTH, HEIGHT, Image.SCALE_DEFAULT);
        ImageIcon resizedImage = new ImageIcon(newImg);

        window.getContentPane().add(new JLabel(resizedImage));
        window.setBounds(475, 250, WIDTH, HEIGHT);
        window.setVisible(true);
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        window.setVisible(false);
        window.dispose();
    }
}

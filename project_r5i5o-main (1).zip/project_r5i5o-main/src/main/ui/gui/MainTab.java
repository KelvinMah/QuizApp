package ui.gui;

import model.EventLog;
import model.Event;
import model.Question;
import model.Quiz;
import persistance.JsonReader;
import persistance.JsonWriter;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

//code influenced by:
//https://stackoverflow.com/questions/47550228/java-using-a-isselected-function-in-radiobuttons-and-jpanel
//https://stackoverflow.com/questions/11565490/need-to-get-input-from-a-radio-button-in-a-jframe-and-use-the-selected-input-in
//https://stackoverflow.com/questions/8299683/java-swing-jmenubar
//https://stackoverflow.com/questions/5654926/implementing-back-forward-buttons-in-swing
//https://docs.oracle.com/javase/tutorial/uiswing/events/windowlistener.html

//Represents main gui frame for quiz app
public class MainTab extends JFrame {
    public static final int WIDTH = 600;
    public static final int HEIGHT = 400;
    private List<Quiz> quizList;
    private JsonReader jsonReader;
    private JsonWriter jsonWriter;
    private JTextArea quizListArea;
    private JPanel mainPanel;
    private ViewCreatedQuizzes displayQuiz;
    private Quiz currentDisplayedQuiz;
    private List<ButtonGroup> buttonGroups;
    private static final String JSON_STORE = "./data/quiz.json";
    private JMenuItem load;
    private JMenuItem save;
    private JMenu fileMenu;
    private JLabel imageLabel;
    private JPanel imagePanel;
    private JButton playQuizButton;
    private JButton addQuizButton;
    private JButton viewQuizzesButton;

    //EFFECTS: to construct a new frame to display all the necessary functions for quiz app
    public MainTab() throws FileNotFoundException {
        initialize();

        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        initializeButtons();

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(playQuizButton);
        buttonPanel.add(addQuizButton);
        buttonPanel.add(viewQuizzesButton);

        quizListArea = new JTextArea();
        quizListArea.setEditable(false);

        dropDownFile();

        mainPanel.add(buttonPanel, BorderLayout.NORTH);
        mainPanel.add(new JScrollPane(quizListArea), BorderLayout.CENTER);
        displayImage();

        add(mainPanel);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);

    }

    //EFFECTS: to initialize the quiz app frame and also all instances
    private void initialize() {
        setTitle("Quiz Application");
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                exitWindow();
                System.exit(0);
            }
        });
        quizList = new ArrayList<>();
        displayQuiz = new ViewCreatedQuizzes(quizList, this);
        buttonGroups = new ArrayList<>();
        fileMenu = new JMenu("File");
        save = new JMenuItem("Save");
        load = new JMenuItem("Load");
        jsonWriter = new JsonWriter(JSON_STORE);
        jsonReader = new JsonReader(JSON_STORE);
    }

    private void initializeButtons() {
        playQuizButton = new JButton("Play Quiz");
        playQuizButton.addActionListener(e -> playQuiz());

        addQuizButton = new JButton("Add Quiz");
        addQuizButton.addActionListener(e -> addQuiz());

        viewQuizzesButton = new JButton("View Quizzes");
        viewQuizzesButton.addActionListener(e -> displayQuizzes());
    }

    private void exitWindow() {
        for (Event e : EventLog.getInstance()) {
            System.out.println(e);
        }
    }

    //EFFECTS: to display image when playing quiz
    private void displayImage() {
        ImageIcon img = new ImageIcon("data/quizImage.jpg");

        Image image = img.getImage();
        Image newImg = image.getScaledInstance(WIDTH, HEIGHT, Image.SCALE_DEFAULT);
        ImageIcon resizedImage = new ImageIcon(newImg);
        imageLabel = new JLabel(resizedImage);
        mainPanel.add(imageLabel, BorderLayout.SOUTH);
    }

    //EFFECTS: to create image panel that displays the image
    private JPanel createImagePanel() {
        imagePanel = new JPanel();
        imagePanel.setLayout(new BorderLayout());
        displayImage();
        imagePanel.add(imageLabel, BorderLayout.CENTER);
        return imagePanel;
    }

    //MODIFIES: this
    //EFFECTS: to create a drop down menu that has save and load function
    private void dropDownFile() {
        save.addActionListener(e -> saveFile());

        load.addActionListener(e -> loadFile());

        fileMenu.add(save);
        fileMenu.add(load);
        JMenuBar menuBar = new JMenuBar();
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);
    }

    //EFFECTS: to play selected quiz
    private void playQuiz() {
        if (quizList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No quizzes available to play!", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        String[] quizTitles = new String[quizList.size()];
        for (int i = 0; i < quizList.size(); i++) {
            quizTitles[i] = quizList.get(i).getTitle();
        }

        String selectedQuiz = (String) JOptionPane.showInputDialog(this, "Select a quiz to play:",
                "Play Quiz", JOptionPane.PLAIN_MESSAGE, null, quizTitles, quizTitles[0]);

        if (selectedQuiz != null) {
            for (Quiz quiz : quizList) {
                if (quiz.getTitle().equals(selectedQuiz)) {
                    displayImage();
                    displayQuizQuestions(quiz);
                    return;
                }
            }
        }
    }

    //MODIFIES: this
    //EFFECTS: to create question panel that displays the questions
    private JPanel createQuestionPanel(Quiz quiz) {
        JPanel questionPanel = new JPanel();
        questionPanel.setLayout(new BoxLayout(questionPanel, BoxLayout.Y_AXIS));

        JTextArea quizTextArea = new JTextArea(quiz.getTitle() + "\n");
        quizTextArea.setFont(new Font("Times New Roman", Font.BOLD, 20));
        quizTextArea.setEditable(false);
        questionPanel.add(quizTextArea);

        for (int i = 0; i < quiz.getNumQuestions(); i++) {
            addQuestionToPanel(questionPanel, i, quiz.getQuestion(i));
        }

        return questionPanel;
    }

    //MODIFIES: this
    //EFFECTS: to add question to the created panel
    private void addQuestionToPanel(JPanel questionPanel, int index, Question question) {
        JTextArea questionText = new JTextArea("Question " + (index + 1) + ": " + question.getQuestion() + "\n");
        questionText.setEditable(false);
        questionText.setFont(new Font("Times New Roman", Font.BOLD, 15));
        questionPanel.add(questionText);

        List<String> answers = question.getAnswers();
        ButtonGroup btnGroup = new ButtonGroup();
        buttonGroups.add(btnGroup);

        for (String answer : answers) {
            JRadioButton answerRadioButton = new JRadioButton(answer);
            questionPanel.add(answerRadioButton);
            btnGroup.add(answerRadioButton);
        }

        questionPanel.add(Box.createRigidArea(new Dimension(0, 10)));
    }

    //MODIFIES: this
    //EFFECTS: to display the questions when playing quiz
    private void displayQuizQuestions(Quiz quiz) {
        getContentPane().removeAll();
        revalidate();
        repaint();

        currentDisplayedQuiz = quiz;
        JPanel questionPanel = createQuestionPanel(quiz);

        JPanel playPanel = new JPanel(new BorderLayout());
        playPanel.add(createImagePanel(), BorderLayout.NORTH);
        playPanel.add(questionPanel, BorderLayout.CENTER);

        JScrollPane scrollPane = new JScrollPane(playPanel);
        add(scrollPane, BorderLayout.CENTER);
        submit();

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    //MODIFIES: this
    //EFFECTS: to submit the user's answers and get the result
    private void submit() {
        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int score = calculateScore();
                int totalQuestions = currentDisplayedQuiz.getNumQuestions();
                String result = "You scored: " + score + " out of " + totalQuestions;
                JOptionPane.showMessageDialog(MainTab.this, result, "Quiz Results",
                        JOptionPane.INFORMATION_MESSAGE);
                backToMain();
            }
        });
        add(submitButton, BorderLayout.SOUTH);
    }

    //MODIFIES: this
    //EFFECTS: calculate score based on the user's selected answer
    private int calculateScore() {
        int score = 0;

        for (int i = 0; i < currentDisplayedQuiz.getNumQuestions(); i++) {
            Question question = currentDisplayedQuiz.getQuestion(i);
            List<String> answers = question.getAnswers();
            int correctAnswerIndex = question.getCorrectAnswers();

            ButtonGroup currentButtonGroup = buttonGroups.get(i);

            Enumeration<AbstractButton> buttons = currentButtonGroup.getElements();
            while (buttons.hasMoreElements()) {
                AbstractButton button = buttons.nextElement();
                if (button.isSelected()) {
                    String selectedAnswerText = button.getText();

                    //debugging
                    System.out.println("Selected: " + selectedAnswerText);
                    System.out.println("Correct: " + answers.get(correctAnswerIndex));

                    if (selectedAnswerText.equals(answers.get(correctAnswerIndex))) {
                        score++;
                    }
                    break;
                }
            }
        }
        return score;
    }

    //MODIFIES: this
    //EFFECTS: prompt the user to create a new quiz with no duplicate quiz title
    private void addQuiz() {
        String title = JOptionPane.showInputDialog("Enter quiz title:");
        for (Quiz quiz : quizList) {
            if (quiz.getTitle().equalsIgnoreCase(title)) {
                JOptionPane.showMessageDialog(this, "A quiz with the same title already exists!",
                        "Duplicate Quiz", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        Quiz quiz = new Quiz(title);
        int numQuestion = Integer.parseInt(JOptionPane.showInputDialog("Enter number of question:"));
        for (int i = 0; i < numQuestion; i++) {
            createQuestion(quiz);
        }
        quizList.add(quiz);
    }

    //MODIFIES: this
    //EFFECTS: prompt the user to enter the number of questions as well as the actual questions for the quiz
    private void createQuestion(Quiz quiz) {
        String question = JOptionPane.showInputDialog("Enter the question: ");
        List<String> ansChoices = new ArrayList<>();
        for (int j = 0; j < 4; j++) {
            String ansChoice = JOptionPane.showInputDialog("Enter the answer choices : \nAnswer choice "
                    + (j + 1) + ": ");
            ansChoices.add(ansChoice);
        }
        Question quizQuestion = new Question(question);
        quizQuestion.setAnswers(ansChoices);
        int correctAns = (Integer.parseInt(JOptionPane.showInputDialog("Enter index of correct answer:")) - 1);
        quizQuestion.setCorrectAnswer(correctAns);
        quiz.addQuestion(quizQuestion);
    }

    //MODIFIES: this
    //EFFECTS: to view the quizzes created
    private void displayQuizzes() {
        if (displayQuiz != null) {
            getContentPane().removeAll();
            revalidate();
            repaint();

            displayQuiz = new ViewCreatedQuizzes(quizList, this);

            setContentPane(displayQuiz);

            pack();
            setLocationRelativeTo(null);
            setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "No Quizzes Found!", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    //EFFECTS: save quiz list created to file
    private void saveFile() {
        try {
            jsonWriter.open();
            jsonWriter.writeQuiz(quizList);
            jsonWriter.close();
            JOptionPane.showMessageDialog(this, "Quizzes saved to file", "Saved",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Unable to write to file: " + JSON_STORE,
                    "Error!", JOptionPane.INFORMATION_MESSAGE);
        }

    }

    //EFFECTS: load quiz list created from file
    private void loadFile() {
        try {
            quizList = jsonReader.readQuiz();
            JOptionPane.showMessageDialog(this, "Quizzes loaded from file", "File Loaded",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Unable to read from file: " + JSON_STORE,
                    "Error!", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    //EFFECTS: return to main panel
    public void backToMain() {
        getContentPane().removeAll();
        getContentPane().add(mainPanel);
        displayImage();
        revalidate();
        repaint();
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

}

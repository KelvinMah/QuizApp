package ui.gui;

import model.Quiz;
import ui.gui.MainTab;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

//code influenced by
//https://docs.oracle.com/javase/tutorial/displayCode.html?code=https://docs.oracle.com/javase/tutorial/uiswing/examples/components/ListDemoProject/src/components/ListDemo.java **/
//Represent the created quizzes
public class ViewCreatedQuizzes extends JPanel implements ListSelectionListener {
    private JList<String> list;
    private DefaultListModel<String> listModel;
    private List<Quiz> quizList;
    private JButton removeQuiz;
    private MainTab main;
    private static final String removeString = "Remove";

    //EFFECTS: Constructs the panel showing the quiz list created
    public ViewCreatedQuizzes(List<Quiz> quizList, MainTab main) {
        this.quizList = quizList;
        this.main = main;
        listModel = new DefaultListModel<>();
        for (int i = 0; i < quizList.size(); i++) {
            Quiz quiz = quizList.get(i);
            listModel.addElement((i + 1) + ". " + quiz.getTitle());
        }
        list = new JList<>(listModel);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setSelectedIndex(0);
        list.addListSelectionListener(this);
        list.setVisibleRowCount(5);
        removeQuiz = new JButton(removeString);
        removeQuiz.setActionCommand(removeString);
        removeQuiz.addActionListener(new RemoveListener());

        setupUI();
        removeQuiz.setEnabled(!listModel.isEmpty());
    }

    //MODIFIES: this
    //EFFECTS: to initialize all fields, and add buttons to main panel
    private void setupUI() {
        setLayout(new BorderLayout());
        JLabel titleLabel = new JLabel("Quiz Created", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
        JScrollPane listScrollPane = new JScrollPane(list);
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> main.backToMain());

        JPanel buttonPane = new JPanel();
        buttonPane.setLayout(new BoxLayout(buttonPane, BoxLayout.LINE_AXIS));
        buttonPane.add(removeQuiz);
        buttonPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        add(titleLabel, BorderLayout.NORTH);
        add(listScrollPane, BorderLayout.CENTER);
        add(buttonPane, BorderLayout.SOUTH);
        add(backButton, BorderLayout.EAST);
    }

    //MODIFIES: this
    //EFFECTS: remove a selected quiz index from the created quiz list
    class RemoveListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int index = list.getSelectedIndex();
            listModel.remove(index);

            if (index >= 0 && index < quizList.size()) {
                quizList.remove(index);
            }

            if (listModel.isEmpty()) {
                removeQuiz.setEnabled(false);
            } else {
                if (index == listModel.getSize()) {
                    index--;
                }
                list.setSelectedIndex(index);
                list.ensureIndexIsVisible(index);
            }
        }
    }

    //EFFECTS: to set the visibility of the remove button
    public void valueChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting()) {
            removeQuiz.setEnabled(list.getSelectedIndex() != -1);
        }
    }
}

package ui;

import ui.gui.SplashScreen;
import ui.gui.MainTab;

import javax.swing.*;
import java.io.FileNotFoundException;

//To initialize quiz application gui
public class QuizAppGUI extends JFrame {
    public static void main(String[] args) {
        try {
            SplashScreen splashScreen = new SplashScreen();
            new QuizAppGUI();
        } catch (FileNotFoundException e) {
            System.out.println("File not found!");
        }
    }

    public QuizAppGUI() throws FileNotFoundException {
        MainTab main = new MainTab();
    }

}
package ui;

import model.Leaderboard;
import model.Question;
import model.Quiz;
import model.QuizScore;
import persistance.JsonReader;
import persistance.JsonWriter;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//code influenced by
//https://github.students.cs.ubc.ca/CPSC210/TellerApp/blob/main/src/main/ca/ubc/cpsc210/bank/ui/TellerApp.java
//Quiz Game Application
public class QuizApp {
    private static final String JSON_STORE = "./data/quiz.json";
    private List<Quiz> quizList;
    private Leaderboard leaderboard;
    private Scanner inp;
    private JsonReader jsonReader;
    private JsonWriter jsonWriter;

    //EFFECTS: runs the quiz game application
    public QuizApp() throws FileNotFoundException {
        inp = new Scanner(System.in);
        quizList = new ArrayList<>();
        leaderboard = new Leaderboard();
        jsonWriter = new JsonWriter(JSON_STORE);
        jsonReader = new JsonReader(JSON_STORE);
        runMenu();
    }

    //MODIFIES: this
    //EFFECTS: processes user input
    private void runMenu() {
        boolean loop = true;
        int choice = 0;
        while (loop) {
            displayMenu();
            choice = inp.nextInt();

            if (choice == 0) {
                loop = false;
                System.out.println("Application exited successfully!");
            } else {
                getUserInput(choice);
            }
        }

    }

    //MODIFIES: this
    //EFFECTS: processes user input
    private void getUserInput(int choice) {
        if (choice == 1) {
            playQuiz();
        } else if (choice == 2) {
            createQuiz();
        } else if (choice == 3) {
            viewQuizList();
        } else if (choice == 4) {
            viewLeaderboard();
        } else if (choice == 5) {
            saveQuizList();
        } else if (choice == 6) {
            loadQuizList();
        } else {
            System.out.println("Invalid input!");
        }
    }

    //EFFECTS: display the main menu to user
    private void displayMenu() {
        System.out.println("Main Menu:");
        System.out.println("1. Play a Quiz");
        System.out.println("2. Create a Quiz");
        System.out.println("3. View Quiz List");
        System.out.println("4. View Leaderboard");
        System.out.println("5. Save Created Quiz List To File");
        System.out.println("6. Load Created Quiz List From File");
        System.out.println("0. Exit");
        System.out.print("Please enter your choice: ");
    }

    //MODIFIES: this
    //EFFECTS: allow the user to select and play quiz created
    protected void playQuiz() {
        viewQuizList();
        System.out.println("Enter the index of the quiz you want to play:");
        inp.nextLine();
        int index = Integer.parseInt(inp.nextLine()) - 1;
        Quiz quiz = quizList.get(index);
        int score = conductQuiz(quiz);
        System.out.println("Your score is " + score + " out of " + quiz.getNumQuestions() + ".");
        leaderboard.addResults(quiz, score, quiz.getNumQuestions());
    }

    //MODIFIES: this
    //EFFECTS: run through all the questions in the selected quiz
    private int conductQuiz(Quiz quiz) {
        int score = 0;
        for (int i = 0; i < quiz.getNumQuestions(); i++) {
            Question question = quiz.getQuestion(i);
            System.out.println("Question " + (i + 1) + ": " + question.getQuestion());
            List<String> ansChoices = question.getAnswers();
            for (int j = 0; j < ansChoices.size(); j++) {
                System.out.println((j + 1) + ": " + ansChoices.get(j));
            }
            System.out.println("Enter your answer:");
            int userAns = Integer.parseInt(inp.nextLine()) - 1;
            if (userAns == question.getCorrectAnswers()) {
                System.out.println("Correct!");
                score++;
            } else {
                System.out.println("Incorrect. The correct answer is " + (question.getCorrectAnswers() + 1) + ".");
            }
        }
        return score;
    }

    // MODIFIES: this
    // EFFECTS: allow user to create new quiz
    private void createQuiz() {
        System.out.println("Enter the name of the quiz:");
        inp.nextLine();
        String quizTitle = inp.nextLine();
        Quiz quiz = new Quiz(quizTitle);
        System.out.println("Enter the number of questions for this quiz:");
        int numQuestions = Integer.parseInt(inp.nextLine());
        for (int i = 0; i < numQuestions; i++) {
            createQuestion(quiz);
        }
        quizList.add(quiz);
    }

    //MODIFIES: this
    //EFFECTS: allow user to set the questions
    private void createQuestion(Quiz quiz) {
        System.out.println("Enter the question:");
        String question = inp.nextLine();
        System.out.println("Enter 4 answer choices:");
        List<String> ansChoices = new ArrayList<>();
        for (int j = 0; j < 4; j++) {
            System.out.println("Answer choice " + (j + 1) + ":");
            String ansChoice = inp.nextLine();
            ansChoices.add(ansChoice);
        }
        Question quizQuestion = new Question(question);
        quizQuestion.setAnswers(ansChoices);
        System.out.println("Enter the index of the correct answer choice (1-4):");
        int correctChoice = Integer.parseInt(inp.nextLine()) - 1;
        quizQuestion.setCorrectAnswer(correctChoice);
        quiz.addQuestion(quizQuestion);
    }

    //MODIFIES: this
    //EFFECTS: display lists of quiz created
    private void viewQuizList() {
        System.out.println("List of created quizzes:");
        for (int i = 0; i < quizList.size(); i++) {
            Quiz quiz = quizList.get(i);
            System.out.println((i + 1) + ". " + quiz.getTitle());
        }
    }

    //MODIFIES: this
    //EFFECTS: display leaderboard
    private void viewLeaderboard() {
        List<QuizScore> scores = leaderboard.getResults();
        scores.sort((a, b) -> Integer.compare(b.getScore(), a.getScore()));

        System.out.println("Leaderboard:");
        for (int i = 0; i < scores.size(); i++) {
            QuizScore quizScore = scores.get(i);
            System.out.println((i + 1) + ". " + quizScore.getQuiz().getTitle() + ": " + quizScore.getScore()
                    + " points out of " + quizScore.getTotalScore());
        }
    }

    //EFFECTS: save quiz list created to file
    private void saveQuizList() {
        try {
            jsonWriter.open();
            jsonWriter.writeQuiz(quizList);
            jsonWriter.close();
            System.out.println("Saved quiz list to " + JSON_STORE);
        } catch (FileNotFoundException e) {
            System.out.println("Unable to write to file: " + JSON_STORE);
        }
    }

    //EFFECTS: load quiz list created from file
    private void loadQuizList() {
        try {
            quizList = jsonReader.readQuiz();
            System.out.println("Loaded quiz list from " + JSON_STORE);
        } catch (IOException e) {
            System.out.println("Unable to read from file: " + JSON_STORE);
        }
    }
}

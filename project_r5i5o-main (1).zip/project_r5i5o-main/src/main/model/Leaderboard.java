package model;

import org.json.JSONArray;
import org.json.JSONObject;
import persistance.Writable;

import java.util.ArrayList;
import java.util.List;

//Represents a leaderboard that displays the title of quizzes played and the corresponding scores
public class Leaderboard {
    private List<QuizScore> results;

    //EFFECTS: constructs an empty list to store the quiz results
    public Leaderboard() {
        results = new ArrayList<>();
    }

    //REQUIRES: score and totalScore >=0
    //MODIFIES: this
    //EFFECTS: add the quizzes played and score obtained in the corresponding quizzes
    public void addResults(Quiz quiz, int score, int totalScore) {
        if (totalScore > 0) {
            results.add(new QuizScore(quiz, score, totalScore));
        }
    }

    //MODIFIES: this
    //EFFECTS: return the score obtained
    public List<QuizScore> getResults() {
        return results;
    }

}

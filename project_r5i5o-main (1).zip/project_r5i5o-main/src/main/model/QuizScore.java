package model;

import org.json.JSONObject;
import persistance.Writable;

//Represents the score for the quiz played
public class QuizScore {
    private Quiz quiz;
    private int score;
    private int totalScore;

    //REQUIRES: score>= 0
    //EFFECTS:  Constructs the quiz played and the score that have been obtained
    public QuizScore(Quiz quiz, int score, int totalScore) {
        this.quiz = quiz;
        this.score = score;
        this.totalScore = totalScore;
    }

    //EFFECTS: return the quiz that have been played
    public Quiz getQuiz() {
        return quiz;
    }

    //EFFECTS: return score obtained in the quiz played
    public int getScore() {
        return score;
    }

    //EFFECTS: return total score available for the quiz
    public int getTotalScore() {
        return totalScore;
    }

}

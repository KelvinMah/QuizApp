package model;

import org.json.JSONArray;
import org.json.JSONObject;
import persistance.Writable;

import java.util.ArrayList;
import java.util.List;

//Represents a question
public class Question implements Writable {
    private String question;
    private List<String> answers;
    private int correctAnswer;

    //REQUIRES: correctAnswers > 0 and correctAnswers < 4
    //EFFECTS: construct a question with the multiple choices of answers and the correct answer
    public Question(String question) {
        this.question = question;
        this.answers = new ArrayList<>();
        this.correctAnswer = -1;

    }

    //EFFECTS: return question asked
    public String getQuestion() {
        return question;
    }

    // EFFECTS: set the list of answers for the question
    public void setAnswers(List<String> answers) {
        this.answers = answers;
        for (int i = 0; i < answers.size(); i++) {
            String answer = answers.get(i);
            EventLog.getInstance().logEvent(new Event("Answer choice " + (i + 1) + " added: " + answer));
        }

    }

    //EFFECTS: return the multiple choices of answers
    public List<String> getAnswers() {
        return answers;
    }

    //EFFECTS: return the index of correct answer to the question
    public int getCorrectAnswers() {
        return correctAnswer;
    }

    // REQUIRES: correctAnswer must be between 0 and the number of choices to the question
    // EFFECTS: set the index of the correct answer
    public void setCorrectAnswer(int correctAnswer) {
        if (correctAnswer >= 0 && correctAnswer < answers.size()) {
            this.correctAnswer = correctAnswer;
        }
        EventLog.getInstance().logEvent(new Event("Correct answer added at index: " + (correctAnswer + 1)));
    }

    //EFFECTS: converts question into a JSONObject
    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("question", question);
        json.put("answers", answersToJson());
        json.put("correctAnswer", correctAnswer);
        return json;
    }

    //EFFECTS: return answers of the question as a JSON array
    private JSONArray answersToJson() {
        JSONArray jsonArray = new JSONArray();

        for (String ans : answers) {
            jsonArray.put(ans);
        }
        return jsonArray;
    }
}

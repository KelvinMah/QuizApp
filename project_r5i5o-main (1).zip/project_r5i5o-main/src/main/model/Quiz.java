package model;

import org.json.JSONArray;
import org.json.JSONObject;
import persistance.Writable;

import java.util.ArrayList;
import java.util.List;

//Represents a quiz having a title, time limit to solve and lists of questions
public class Quiz implements Writable {
    private String title;
    private List<Question> questions;

    //REQUIRES: time limit > 0
    //EFFECTS: constructs quiz title and also creates an empty questions list
    public Quiz(String title) {
        this.title = title;
        questions = new ArrayList<>();
        EventLog.getInstance().logEvent(new Event("New quiz added to quiz list: " + title));
    }

    //MODIFIES: this
    //EFFECTS: add question to the list created
    public void addQuestion(Question question) {
        questions.add(question);
        EventLog.getInstance().logEvent(new Event("Question added to " + title + ": "
                + question.getQuestion()));
    }

    //EFFECTS: return quiz title
    public String getTitle() {
        EventLog.getInstance().logEvent(new Event("Viewed created quizzes "));
        return this.title;
    }

    //MODIFIES: this
    //EFFECTS: return question at given index
    public Question getQuestion(int index) {
        return questions.get(index);
    }

    //EFFECTS: return total number of questions in the list
    public int getNumQuestions() {
        return questions.size();
    }

    public List<Question> getQuestionsWithAnswer(int answer) {
        List<Question> results = new ArrayList<Question>();
        for (Question q : questions) {
            if (q.getCorrectAnswers() == answer) {
                results.add(q);
            }
        }
        return results;
    }

    //EFFECTS: converts quiz to JSON object
    @Override
    public JSONObject toJson() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("title", title);

        JSONArray questionsArray = new JSONArray();
        for (Question question : questions) {
            questionsArray.put(question.toJson());
        }
        jsonObject.put("questions", questionsArray);

        return jsonObject;
    }
}

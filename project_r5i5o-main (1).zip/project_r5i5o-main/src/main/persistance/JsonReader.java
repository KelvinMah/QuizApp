package persistance;

import model.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Stream;

// Represents a reader that reads quiz created from JSON data stored in file
//Code influenced by the JsonSerizalizationDemo
//https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo/blob/master/src/main/persistence/JsonReader.java
public class JsonReader {
    private String source;

    // EFFECTS: constructs reader to read from source file
    public JsonReader(String source) {
        this.source = source;
    }

    // EFFECTS: reads quiz list created from file and returns it;
    // throws IOException if an error occurs reading data from file
    public List<Quiz> readQuiz() throws IOException {
        String jsonData = readFile(source);
        JSONArray jsonArray = new JSONArray(jsonData);
        List<Quiz> quizzes = new ArrayList<>();

        for (Object obj : jsonArray) {
            JSONObject quizJson = (JSONObject) obj;
            Quiz quiz = parseQuiz(quizJson);
            quizzes.add(quiz);
        }
        EventLog.getInstance().logEvent(new Event("File loaded from: " + source));
        return quizzes;
    }

    // EFFECTS: reads source file as string and returns it
    private String readFile(String source) throws IOException {
        StringBuilder contentBuilder = new StringBuilder();

        try (Stream<String> stream = Files.lines(Paths.get(source), StandardCharsets.UTF_8)) {
            stream.forEach(s -> contentBuilder.append(s));
        }

        return contentBuilder.toString();
    }

    // EFFECTS: parses quiz from JSON object and returns it
    private Quiz parseQuiz(JSONObject jsonObject) {
        String title = jsonObject.getString("title");
        Quiz quiz = new Quiz(title);
        addQuestions(quiz, jsonObject);
        return quiz;
    }

    // MODIFIES: quiz
    // EFFECTS: parses questions from JSON object and adds them to quiz
    private void addQuestions(Quiz quiz, JSONObject jsonObject) {
        JSONArray jsonArray = jsonObject.getJSONArray("questions");
        for (Object json : jsonArray) {
            JSONObject nextQuestion = (JSONObject) json;
            addQuestion(quiz, nextQuestion);
        }
    }

    // MODIFIES: quiz
    // EFFECTS: parses question from JSON object and adds it to quiz
    private void addQuestion(Quiz quiz, JSONObject jsonObject) {
        String questionText = jsonObject.getString("question");
        Question question = new Question(questionText);
        question.setAnswers(parseAnswers(jsonObject.getJSONArray("answers")));
        question.setCorrectAnswer(jsonObject.getInt("correctAnswer"));
        quiz.addQuestion(question);
    }

    //EFFECTS: parses answers from JSON array and returns it
    private List<String> parseAnswers(JSONArray jsonArray) {
        List<String> answers = new ArrayList<>();
        for (Object json : jsonArray) {
            answers.add((String) json);
        }
        return answers;
    }

}

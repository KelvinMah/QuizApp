package persistance;

import model.Question;
import model.Quiz;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class TestJsonReader {
    @Test
    void testReaderNonExistentFile() {
        JsonReader reader = new JsonReader("./data/noSuchFile.json");
        try {
            List<Quiz> quiz = reader.readQuiz();
            fail("IOException expected");
        } catch (IOException e) {
            // pass
        }
    }

    @Test
    void testReaderEmptyQuiz() {
        JsonReader reader = new JsonReader("./data/testWriterEmptyQuiz.json");
        try {
            List<Quiz> quiz = reader.readQuiz();
            assertEquals(0, quiz.size());
        } catch (IOException e) {
            fail("Couldn't read from file");
        }
    }

    @Test
    void testReaderGeneralQuiz() {
        JsonReader reader = new JsonReader("./data/testWriterGeneralQuiz.json");
        try {
            List<Quiz> readQuizzes = reader.readQuiz();

            assertEquals(1, readQuizzes.size());
            Quiz readQuiz = readQuizzes.get(0);

            assertEquals("quiz1", readQuiz.getTitle());

            Question readQuestion = readQuiz.getQuestion(0);

            assertEquals("What is 1 + 1?", readQuestion.getQuestion());
            assertEquals(List.of("1", "2", "3", "4"), readQuestion.getAnswers());
            assertEquals(1, readQuestion.getCorrectAnswers());
        } catch (IOException e) {
            fail("Couldn't read from file");
        }
    }
}

package persistance;

import model.Question;
import model.Quiz;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class TestJsonWriter {
    private Question question;

    @BeforeEach
    void setUp() {
        question = new Question("What is 1 + 1?");
        question.setAnswers(List.of("1", "2", "3", "4"));
        question.setCorrectAnswer(1);
    }

    @Test
    void testWriterInvalidFile() {
        try {
            List<Quiz> quizzes = new ArrayList<>();
            Quiz quiz = new Quiz("quiz1");
            quizzes.add(quiz);
            JsonWriter writer = new JsonWriter("./data/my\0illegal:fileName.json");
            writer.open();
            fail("IOException was expected");
        } catch (IOException e) {
            // pass
        }
    }

    @Test
    void testWriterEmptyQuizList() {
        try {
            List<Quiz> quizzes = new ArrayList<>();

            JsonWriter writer = new JsonWriter("./data/testWriterEmptyQuiz.json");
            writer.open();
            writer.writeQuiz(quizzes);
            writer.close();

            JsonReader reader = new JsonReader("./data/testWriterEmptyQuiz.json");
            List<Quiz> readQuiz = reader.readQuiz();

            assertEquals(0, readQuiz.size());
        } catch (IOException e) {
            fail("Exception should not have been thrown");
        }
    }

    @Test
    void testWriterGeneralQuiz() {
        try {
            List<Quiz> quizzes = new ArrayList<>();
            Quiz quiz = new Quiz("quiz1");
            quiz.addQuestion(question);
            quizzes.add(quiz);
            JsonWriter writer = new JsonWriter("./data/testWriterGeneralQuiz.json");
            writer.open();
            writer.writeQuiz(quizzes);
            writer.close();
            JsonReader reader = new JsonReader("./data/testWriterGeneralQuiz.json");
            List<Quiz> readQuizzes = reader.readQuiz();
            assertEquals(1, readQuizzes.size());
            Quiz readQuiz = readQuizzes.get(0);
            assertEquals(quiz.getTitle(), readQuiz.getTitle());
            Question readQuestion = readQuiz.getQuestion(0);
            assertEquals(question.getQuestion(), readQuestion.getQuestion());
            assertEquals(question.getAnswers(), readQuestion.getAnswers());
            assertEquals(question.getCorrectAnswers(), readQuestion.getCorrectAnswers());
        } catch (IOException e) {
            fail("Exception should not have been thrown");
        }
    }
}

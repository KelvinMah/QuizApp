package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestLeaderboard {
    private Leaderboard leaderboard;
    private Quiz quiz1;
    private Quiz quiz2;

    @BeforeEach
    public void setUp() {
        leaderboard = new Leaderboard();
        quiz1 = new Quiz("Quiz 1");
        quiz2 = new Quiz("Quiz 2");
    }

    @Test
    public void testAddResults() {
        leaderboard.addResults(quiz1, 80, 100);
        leaderboard.addResults(quiz2, 70, 100);

        List<QuizScore> results = leaderboard.getResults();
        assertEquals(2, results.size());

        QuizScore result1 = results.get(0);
        assertEquals(quiz1, result1.getQuiz());
        assertEquals(80, result1.getScore());
        assertEquals(100, result1.getTotalScore());

        QuizScore result2 = results.get(1);
        assertEquals(quiz2, result2.getQuiz());
        assertEquals(70, result2.getScore());
        assertEquals(100, result2.getTotalScore());
    }

    @Test
    public void testAddingFalseResults() {
        leaderboard.addResults(quiz1, 80, 0);
        leaderboard.addResults(quiz2, 70, -10);

        List<QuizScore> results = leaderboard.getResults();
        assertEquals(0, results.size());
    }
}

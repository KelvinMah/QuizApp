package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TestQuiz {
    private Quiz quiz;
    private Question question1;
    private Question question2;

    @BeforeEach
    public void setUp() {
        quiz = new Quiz("Quiz 1");

        question1 = new Question("What is 2 + 2?");
        question1.setAnswers(List.of("3", "4", "5", "6"));
        question1.setCorrectAnswer(1);

        question2 = new Question("What is the capital of Canada?");
        question2.setAnswers(List.of("Toronto", "Montreal", "Ottawa", "Vancouver"));
        question2.setCorrectAnswer(2);
    }

    @Test
    public void testGetTitle() {
        assertEquals("Quiz 1", quiz.getTitle());
    }

    @Test
    public void testAddQuestion() {
        quiz.addQuestion(question1);
        quiz.addQuestion(question2);

        assertEquals(2, quiz.getNumQuestions());
    }

    @Test
    public void testGetQuestion() {
        quiz.addQuestion(question1);
        quiz.addQuestion(question2);

        assertEquals(question1, quiz.getQuestion(0));
        assertEquals(question2, quiz.getQuestion(1));
    }

    @Test
    public void testGetNumQuestions() {
        quiz.addQuestion(question1);
        quiz.addQuestion(question2);

        assertEquals(2, quiz.getNumQuestions());
    }

    @Test
    public void testNoQuestions() {
        assertEquals(0, quiz.getNumQuestions());
    }

    @Test
    public void testGetQuestionsWithResult() {
        quiz.addQuestion(question1);
        quiz.addQuestion(question2);
        List<Question> results = quiz.getQuestionsWithAnswer(1);
        assertEquals(results.size(), 1);
        assertEquals(results.get(0).getQuestion(), "What is 2 + 2?");
    }
}

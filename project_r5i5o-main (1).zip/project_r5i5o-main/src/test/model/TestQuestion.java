package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TestQuestion {
    private Question question;

    @BeforeEach
    public void setUp() {
        question = new Question("What is 1 + 1?");
    }

    @Test
    public void testGetQuestion() {
        assertEquals("What is 1 + 1?", question.getQuestion());
        assertTrue(question.getAnswers().isEmpty());
        assertEquals(-1, question.getCorrectAnswers());
    }

    @Test
    public void testGetAnswers() {
        question.setAnswers(List.of("1", "2", "3", "4"));
        question.setCorrectAnswer(1);
        assertEquals(1, question.getCorrectAnswers());
        assertEquals(List.of("1", "2", "3", "4"), question.getAnswers());
    }


    @Test
    public void testQuestionWithNoAnswers() {
        Question questionWithNoAnswers = new Question("What is 2 + 2?");
        assertEquals(0, questionWithNoAnswers.getAnswers().size());
    }

    @Test
    public void testSettingCorrectAnswerOutOfBounds() {
        question.setCorrectAnswer(5);
        assertEquals(-1, question.getCorrectAnswers());
        question.setCorrectAnswer(-1);
        assertEquals(-1, question.getCorrectAnswers());
    }

}
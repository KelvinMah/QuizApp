package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestQuizScore {
    private QuizScore quizScore;
    private Quiz quiz;

    @BeforeEach
    public void setUp() {
        quiz = new Quiz("Sample Quiz");
        quizScore = new QuizScore(quiz, 80, 100);
    }

    @Test
    public void testGetQuiz() {
        Quiz pastQuiz = quizScore.getQuiz();
        assertEquals(quiz, pastQuiz);
    }

    @Test
    public void testGetScore() {
        int pastScore = quizScore.getScore();
        assertEquals(80, pastScore);
    }

    @Test
    public void testGetTotalScore() {
        int pastTotalScore = quizScore.getTotalScore();
        assertEquals(100, pastTotalScore);
    }
}
